# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end


Refile.secret_key = 'c69ff97ba80978b92cca7e33162ed5bc045781e14204457da1f13612b6ce9f998e871fe800678a05920cb83e988b5ef748d82785424184ede92a4a8cb315c185'